from distutils.core import setup

setup(name='bf4.gg',
      version='1.0',
      py_modules=['bf4_data','bf4_first','bf4_gmail',
                  'bf4_main','bf4_noti','bf4_player',
                  'bf4_rank','bf4_setup','bf4_stats',
                  'bf4_teller','bf4_vehicle','bf4_weapons']
      )
